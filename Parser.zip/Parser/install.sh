apt-get install unzip
unzip Parser.zip
cd Parser
sudo python leakDataImporter.py 2000 3000