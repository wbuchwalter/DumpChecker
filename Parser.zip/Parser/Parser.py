import DumpFinder
import DumpParser
from time import sleep

dumpFinder = DumpFinder.DumpFinder("https://twitter.com/dumpmon")
newDumpsUrls = dumpFinder.getNewDumpsUrls()

for dumpUrl in newDumpsUrls:
    sleep(5)
    dumpParser = DumpParser.DumpParser(dumpUrl)
    dumpParser.parse()





