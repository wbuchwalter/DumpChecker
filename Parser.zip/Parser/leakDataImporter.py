from time import sleep
import urllib
import datetime
import sys


def getData(url):
    raw = urllib.urlopen(url)
    html = raw.read()
    return html


fi = open('leakUrls.txt')
lines = fi.readlines()
sliceStart = int(sys.argv[1])
sliceEnd = int(sys.argv[2])
slicedLines = lines[sliceStart:sliceEnd]
i = sliceStart
startDate = datetime.datetime.now()
for dumpUrl in slicedLines:
    sleep(5)
    originalUrl = dumpUrl.rstrip('\n')
    if dumpUrl.find('pastebin') != -1:
        dumpUrl = originalUrl + '&paste_key=a03d8090fb48c45a9941c59d4c654859'
    i += 1
    stepDate = datetime.datetime.now()
    deltaTime = stepDate - startDate
    print('--- running since ' + str(deltaTime) + '\n --- parsing '+repr(i)+' :' + dumpUrl + '\n')
    rawData = getData(dumpUrl)
    wf = open('dumpFiles/' + repr(i) + '.txt', 'w')
    finalData = originalUrl+ '\n' + rawData
    wf.write(finalData)

